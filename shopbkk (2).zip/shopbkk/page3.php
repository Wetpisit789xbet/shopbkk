<!DOCTYPE html>
<html lang="en">
<head>
<?php require 'head.php'; ?>
      <style>
            div#main-container {
                max-width: 1000px;
            }
            div.card {
                  min-width: 130px;
                  max-width: 150px;
            }       
            div.card img {
                  max-width: 100px;
                  max-height: 100px;
            }           
            div.card * {
                  font-size: 0.9rem;
            }          
            hr {
                  width: 93%;
                  background: #eee;
                  margin-top: 30px;
            }
      </style>
      <script>
      $(function() {

      });
      </script>
</head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bb"background="image/sons.jpg">
<?php require 'navbar.php'; ?> 
<br>
    <div style="font-size:50pt; color:black; text-transform: uppercase;" ><b> Sons of anachy </b></div>


<br><div class="button-contanier"></br>
  <img src="https://th-test-11.slatic.net/p/a738c01795cb5be00b593baa869abfa3.jpg" style="width: 400px;"align=left hspace="20" vspace="20" >
  <div class="h1-button ">
    <h1 class=" text-center  font-bold text-black text-4xl ">Mayan mc</h1></br>
    <p class="text-black text-bold text-2xl"> ล่าสุดตอนนี้มีทั้งหมด 3 season   โดยเนื้อเรื่องในซีซั่นที่ 1 จะเป็นการพูดถึงเรื่องธุรกิจค้ายาระหว่าง Mayans และเจ้าพ่อค้ายารายใหญ่อย่าง Galindo Cartel และจะมีการพูดถึงเรื่องการตายของแม่ Ez และก่อนจบของซีซั่นท่านประธานผู้สร้างคลับ Mayans หรือที่เรียกว่า El Padrino ได้ออกจากคลับที่ตัวเองสร้างขึ้นมาเพื่อนไปทำงานกับ Galindo และในตอนสุดท้ายของซีซั่นจะได้พบกับผู้ที่ฆ่าแม่ของ Ez
      
      
      
      </p>  <br clear=left>
    
</body>
</html>