<!DOCTYPE html>
<html lang="en">
<head>
<?php require 'head.php'; ?>
      <style>
            div#main-container {
                max-width: 1000px;
            }
            div.card {
                  min-width: 130px;
                  max-width: 150px;
            }       
            div.card img {
                  max-width: 100px;
                  max-height: 100px;
            }           
            div.card * {
                  font-size: 0.9rem;
            }          
            hr {
                  width: 93%;
                  background: #eee;
                  margin-top: 30px;
            }
      </style>
      <script>
      $(function() {

      });
      </script>
</head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bb"background="image/sons.jpg">
<?php require 'navbar.php'; ?> 
<br>
    <div style="font-size:50pt; color:black; text-transform: uppercase;" ><b> Sons of anachy </b></div>


<br><div class="button-contanier"></br>
  <img src="https://m.media-amazon.com/images/M/MV5BMTQ1NDU0MTQzM15BMl5BanBnXkFtZTgwNDk5NzU2MzE@._V1_.jpg" style="width: 400px;"align=left hspace="20" vspace="20" >
  <div class="h1-button ">
    <h1 class=" text-center  font-bold text-black text-4xl ">Sons of anachy</h1></br>
    <p class="text-black text-bold text-2xl">“Sons of Anarchy” มีตัวละครเอกคือ “แจ็คสัน เทลเลอร์” (รับบทโดยชาร์ลี ฮันนัม) หรือ “แจ็คซ์” ลูกชายของ “จอห์น เทลเลอร์” ผู้ก่อตั้งแกงค์มอเตอร์ไซด์ “ซันส์ ออฟ อานาคี่” ผู้ล่วงลับ
      โดยแจ็คซ์ปัจจุบันรับตำแหน่ง “รองประธาน” ของสาขาหลักที่ชื่อ “เร้ดวู้ด ออริจินอล” ซึ่งมี “เคลย์ มอร์โรว์” (รอน เพิร์ลแมน) สมาชิกก่อตั้ง รับบทประธาน แถมยังเป็นพ่อบุญธรรมของแจ็คซ์ไปในตัว เพราะเคลย์แต่งงานอยู่กินกับ “เจมม่า” (เคธี ซากัล) แม่ของแจ็คซ์
      “เจมม่า” และ “เคลย์” 2 ตัวละครสำคัญ ซึ่งใกล้ชิดกับแจ็คซ์[Source : Sons of Anarchy (Blogspot)]แม้ “ซันส์ ออฟ อานาคี่” จะมีฉากหน้าเป็นสมาคมคนรักมอเตอร์ไซด์บิ๊กไบค์ และเปิดอู่ซ่อมรถ แต่เบื้องหลังพวกเขามีกิจการหารายได้เถื่อน โดยสาขาเร้ดวู้ดฯ มีธุรกิจปืนเถื่อนกับพวกไอริช ส่งผลให้ถูกจับตาโดยตำรวจท้องที่, รัฐบาลกลาง และแน่นอนว่ามีแกงค์อื่น ซึ่งมีส่วนได้ส่วนเสีย เข้ามาพัวพันด้วยตลอด
      การดำเนินงานของสาขาดูจะเป็นไปได้ด้วยดี แต่การไปเจอเอกสารเกี่ยวกับแกงค์ ที่พ่อทิ้งไว้ ทำให้แจ็คซ์เริ่มกลับมาหยุดคิดถึงเป้าหมาย และทิศทางของแกงค์ ซึ่งนั่นสร้างความกังวลให้กับเคลย์ และเจมม่า ซึ่งคิดว่าทุกอย่างอาจเปลี่ยนไป จากที่ควรเป็น
      
      
      
      </p>  <br clear=left>
    
</body>
</html>