<?php @session_start(); ?>
<!DOCTYPE html>
<html>
<head>
      <?php require 'head.php'; ?>
      <style>
            div#main-container {
                max-width: 1000px;
            }
            div.card {
                  min-width: 130px;
                  max-width: 150px;
            }       
            div.card img {
                  max-width: 100px;
                  max-height: 100px;
            }           
            div.card * {
                  font-size: 0.9rem;
            }          
            hr {
                  width: 93%;
                  background: #eee;
                  margin-top: 30px;
            }
      </style>
      <script>
      $(function() {

      });
      </script>
</head>
<body class="px-3 pt-5" background="image/sons.jpg">

<?php require 'navbar.php'; ?> 
    
<div style="font-size:50pt; color: black; text-transform: uppercase;" ><b> Sons of anachy </b></div>

    <img src="https://m.media-amazon.com/images/I/61VYBqIGYhL._AC_SY780_.jpg" style="width: 400px;" hspace="20" vspace="20" >
    <div class="h1-button ">
      <br><h1 class=" text-center  font-bold text-white text-4xl "> </h1></br>
      <p class="text-white">
        </p>  <br clear=left>
    </div>
<?php require 'footer.php'; ?>     
</body>
</html>
