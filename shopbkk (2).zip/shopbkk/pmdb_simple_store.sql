-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2023 at 03:11 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pmdb_simple_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `member_id` mediumint(8) UNSIGNED NOT NULL,
  `product_id` mediumint(8) UNSIGNED NOT NULL,
  `quantity` smallint(5) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`member_id`, `product_id`, `quantity`) VALUES
(1, 1, 2),
(1, 5, 1),
(3, 1, 5),
(3, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(20) NOT NULL,
  `firstname` varchar(150) NOT NULL,
  `lastname` varchar(150) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id`, `email`, `password`, `firstname`, `lastname`, `address`, `phone`) VALUES
(3, 'notmera12@gmail.com', '7H9Gc2aBvkivs9b', 'Not', 'Mera', '128/1\r\nNomemi', '+66-64-595-7468');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `member_id` mediumint(8) UNSIGNED NOT NULL,
  `firstname` varchar(150) NOT NULL,
  `lastname` varchar(150) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(150) NOT NULL,
  `payment` varchar(250) NOT NULL,
  `pay_status` set('pending','paid') NOT NULL,
  `order_date` date NOT NULL,
  `bank_transfer` varchar(250) NOT NULL,
  `date_transfer` date NOT NULL,
  `time_transfer` time NOT NULL,
  `delivery` set('no','yes') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `member_id`, `firstname`, `lastname`, `address`, `phone`, `payment`, `pay_status`, `order_date`, `bank_transfer`, `date_transfer`, `time_transfer`, `delivery`) VALUES
(4, 3, 'Not', 'Mera', '128/1\r\nNomemi', '+66-64-595-7468', 'cod', 'pending', '2023-03-02', '', '0000-00-00', '00:00:00', 'no'),
(5, 3, 'Not', 'Mera', '128/1\r\nNomemi', '+66-64-595-7468', 'cod', 'pending', '2023-03-03', '', '0000-00-00', '00:00:00', 'no'),
(6, 3, 'Not', 'Mera', '128/1\r\nNomemi', '+66-64-595-7468', 'cod', 'pending', '2023-03-03', '', '0000-00-00', '00:00:00', 'no'),
(7, 3, 'Not', 'Mera', '128/1\r\nNomemi', '+66-64-595-7468', 'cod', 'pending', '2023-03-03', '', '0000-00-00', '00:00:00', 'no'),
(8, 3, 'Not', 'Mera', '128/1\r\nNomemi', '+66-64-595-7468', 'cod', 'pending', '2023-03-03', '', '0000-00-00', '00:00:00', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `orders_item`
--

CREATE TABLE `orders_item` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` mediumint(8) UNSIGNED NOT NULL,
  `product_id` mediumint(8) UNSIGNED NOT NULL,
  `quantity` smallint(5) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `orders_item`
--

INSERT INTO `orders_item` (`id`, `order_id`, `product_id`, `quantity`) VALUES
(3, 2, 1, 1),
(4, 2, 5, 1),
(5, 3, 9, 1),
(6, 4, 1, 1),
(7, 4, 2, 1),
(8, 4, 3, 1),
(9, 4, 4, 1),
(10, 4, 5, 1),
(11, 5, 1, 1),
(12, 5, 2, 1),
(13, 5, 3, 1),
(14, 5, 5, 1),
(15, 7, 1, 1),
(16, 7, 4, 1),
(17, 8, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `name` varchar(150) NOT NULL,
  `detail` text NOT NULL,
  `price` double UNSIGNED NOT NULL,
  `remain` smallint(5) UNSIGNED NOT NULL,
  `delivery_cost` mediumint(8) UNSIGNED NOT NULL,
  `img_files` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `detail`, `price`, `remain`, `delivery_cost`, `img_files`) VALUES
(1, 'เสื้อฮู๊ด', '<p><span style=\"display: inline !important; float: none; background-color: transparent; color: rgb(44, 67, 89); font-family: Tahoma; font-size: 14px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\">เสื้อฮู๊ดดูดม้า</span></p>', 1099, 10, 50, '1-1.jfif'),
(2, 'เสื้อฮู๊ดสีเทา', '<p><span style=\"display: inline !important; float: none; background-color: transparent; color: rgb(44, 67, 89); font-family: Tahoma; font-size: 14px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\">เสื้อฮู๊ดสีเทา</span></p>', 500, 20, 20, '2-1.jfif'),
(3, 'เสื้อกั๊กMayan', '<p><span style=\"display: inline !important; float: none; background-color: transparent; color: rgb(44, 67, 89); font-family: Tahoma; font-size: 14px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\">เสื้อแก๊งกั๊กMayan</span></p>', 300, 20, 30, '3-1.jfif'),
(4, 'เสื้อยืดson of', '<p><span style=\"display: inline !important; float: none; background-color: transparent; color: rgb(44, 67, 89); font-family: Tahoma; font-size: 14px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\">เสื้อยืด over size</span></p>', 999, 5, 100, '4-1.jfif'),
(5, 'แจ็คเก็ตหนัง', '<p><span style=\"display: inline !important; float: none; background-color: transparent; color: rgb(44, 67, 89); font-family: Tahoma; font-size: 14px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\">แจ็คเก็ตหนัง Mayan gang</span></p>', 790, 5, 50, '5-1.jfif'),
(6, 'โมเดลรถของเล่น', '<p><span style=\"display: inline !important; float: none; background-color: transparent; color: rgb(44, 67, 89); font-family: Tahoma; font-size: 14px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\">โมเดลรถเลียนแบบในซีรีย์</span></p>', 499, 0, 40, '6-1.jfif'),
(7, 'โมเดลรถ', '<p><span style=\"display: inline !important; float: none; background-color: transparent; color: rgb(44, 67, 89); font-family: Tahoma; font-size: 14px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\">โมเดลรถเลียนแบบในซีรีย์</span></p>', 5000, 2, 100, '7-1.jfif'),
(8, 'โมเดลรถ', '<p><span style=\"display: inline !important; float: none; background-color: transparent; color: rgb(44, 67, 89); font-family: Tahoma; font-size: 14px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\">โมเดลรถเลียนแบบในซีรีย์</span></p>', 400, 8, 40, '8-1.jfif'),
(9, 'โมเดลรถ', '<p><span style=\"display: inline !important; float: none; background-color: transparent; color: rgb(44, 67, 89); font-family: Tahoma; font-size: 14px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\">โมเดลรถเลียนแบบในซีรีย์</span></p>', 500, 5, 50, '9-1.jfif'),
(10, 'แหวนmcตัวตึง', '<p><span style=\"display: inline !important; float: none; background-color: transparent; color: rgb(44, 67, 89); font-family: Tahoma; font-size: 14px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\">ใส่แล้ววิบวับจัด</span></p>', 800, 8, 80, '10-1.jfif');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`member_id`,`product_id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders_item`
--
ALTER TABLE `orders_item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders_item`
--
ALTER TABLE `orders_item`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
